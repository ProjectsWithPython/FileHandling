Package for File Handling

**Getting started**
```py
from EasyFileHandling.main import FileHandler

x = FileHandler('test.py', 'py')

print(x.get_file_content()) 

```